# Archer Full AI

Assistant vocal personnel Android intelligent avec wake-word “Archer”, reconnaissance vocale avancée, synthèse vocale, interface futuriste et commandes locales/IA.

## Fonctionnalités

- Wake-word “Archer” (Porcupine SDK)
- Reconnaissance et synthèse vocale (Android, multi-profils)
- Réponses IA via Hugging Face LLM
- Interface UI moderne, effets néon, animations
- Commandes utiles : réveil, météo, musique, salutations
- Profils utilisateurs (reconnaissance voix, préférences)
- Service background pour écoute continue
- Logging interactions

## Architecture

```
ArcherFullAI/
├── README.md
├── build.gradle
├── settings.gradle
├── gradle.properties
├── gradle/
├── app/
│   ├── build.gradle
│   ├── src/
│   │   └── main/
│   │       ├── java/com/archer/ai/
│   │       │   ├── MainActivity.kt
│   │       │   ├── WakeWordService.kt
│   │       │   ├── HuggingFaceClient.kt
│   │       │   ├── CommandHandler.kt
│   │       │   └── UserProfileManager.kt
│   │       ├── res/
│   │       │   ├── layout/
│   │       │   │   └── activity_main.xml
│   │       │   ├── values/
│   │       │   │   ├── colors.xml
│   │       │   │   └── styles.xml
│   │       │   ├── drawable/
│   │       │   │   └── ic_launcher.png
│   │       │   └── anim/
│   │       ├── assets/
│   │       │   ├── archer.ppn
│   │       │   └── sounds/
│   │       │       └── notification.mp3
│   │       └── AndroidManifest.xml
└── gradle-wrapper/
```

## Installation & Build

- Ouvre dans Android Studio
- Compile et lance sur ton téléphone/tablette Android (API 26+)
- Ajoute tes clés et assets dans `/assets`
- APK compatible build cloud (Google Cloud Build, Codemagic)

---

## Fichiers clés à modifier

| Fichier                  | Rôle principal                                 |
|--------------------------|------------------------------------------------|
| MainActivity.kt          | UI principale, micro, TTS, liaison IA          |
| WakeWordService.kt       | Service foreground, wake-word, écoute continue |
| HuggingFaceClient.kt     | Requêtes HTTP vers Hugging Face                |
| CommandHandler.kt        | Analyse commandes locales                      |
| UserProfileManager.kt    | Gestion profils utilisateurs                   |
| activity_main.xml        | UI futuriste                                   |
| colors.xml / styles.xml  | Thème sombre & néon                            |

---

## Permissions requises

- Microphone
- Internet
- Foreground service

---

## Liens utiles

- [Porcupine Wake Word](https://picovoice.ai/products/wake-word/)
- [SpeechRecognizer Android](https://developer.android.com/reference/android/speech/SpeechRecognizer)
- [Hugging Face Inference API](https://huggingface.co/inference-api)

---

## Auteur

Projet pour naelboumeddane-lab