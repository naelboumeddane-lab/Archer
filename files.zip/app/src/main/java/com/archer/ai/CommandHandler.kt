package com.archer.ai

// Analyse commandes locales avant IA
object CommandHandler {
    // TODO: Méthode d'analyse, retourne action ou null
}