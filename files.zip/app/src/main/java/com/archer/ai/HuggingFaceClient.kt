package com.archer.ai

// Gère les requêtes HTTP vers Hugging Face (LLM)
object HuggingFaceClient {
    // TODO: Méthodes pour envoyer texte et recevoir réponse IA
}