package com.archer.ai

// Gestion des profils utilisateurs (voix, préférences, logs)
object UserProfileManager {
    // TODO: CRUD profils, reconnaissance voix, logs
}