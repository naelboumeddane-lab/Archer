package com.archer.ai

import android.app.Service
import android.content.Intent
import android.os.IBinder

// Service foreground pour écoute Wake-word "Archer"
class WakeWordService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        // TODO: Init Porcupine, écoute continue, notification
    }

    override fun onDestroy() {
        super.onDestroy()
        // TODO: Stopper écoute Porcupine
    }
}